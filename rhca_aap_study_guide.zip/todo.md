# RHCA AAP Study Guide Todo List

## Research Phase
- [x] Research EX374 exam objectives
- [x] Research AAP installation requirements for single-node setup
- [x] Research PostgreSQL configuration requirements for AAP
- [x] Research Proxmox VM setup requirements

## Setup Guides
- [x] Create Proxmox VM setup guide
- [x] Create AAP installation guide (Automation Controller + Private Automation Hub)
- [x] Create PostgreSQL database configuration guide

## EX374 Guided Labs
- [x] Lab: Git Repository Management
  - [x] Cloning repositories
  - [x] Creating and pushing files
  - [x] Managing inventory files

- [x] Lab: Task Execution Management
  - [x] Controlling privilege execution
  - [x] Running selected tasks from playbooks

- [x] Lab: Data Transformation with Filters and Plugins
  - [x] Using lookup plugins
  - [x] Implementing advanced loops
  - [x] Manipulating network information variables

- [x] Lab: Task Delegation
  - [x] Running tasks on different hosts
  - [x] Controlling fact delegation

- [x] Lab: Content Collection Management
  - [x] Creating content collections
  - [x] Installing content collections
  - [x] Using collections in playbooks
  - [x] Uploading to automation hub

- [x] Lab: Execution Environment Management
  - [x] Creating execution environments
  - [x] Uploading to automation hub
  - [x] Using in automation controller

- [x] Lab: Inventory and Credential Management
  - [x] Managing advanced inventories
  - [x] Creating dynamic inventories
  - [x] Setting up credentials

- [x] Lab: Automation Controller Management
  - [x] Running playbooks in controller
  - [x] Pulling content from Git/hub
  - [x] Using execution environments

## GitHub Repository
- [x] Create repository structure
- [x] Add README.md with project overview
- [x] Add installation guides
- [x] Add lab guides
- [x] Add sample code and playbooks
- [x] Add troubleshooting section
- [x] Finalize and validate repository
